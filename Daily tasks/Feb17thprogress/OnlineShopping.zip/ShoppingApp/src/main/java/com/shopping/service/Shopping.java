package com.shopping.service;

public interface Shopping {
    void purchase();
}
